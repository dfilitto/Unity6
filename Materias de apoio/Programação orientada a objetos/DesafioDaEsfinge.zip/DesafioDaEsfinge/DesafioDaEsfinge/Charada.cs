﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesafioDaEsfinge
{
    public class Charada
    {
        public Charada()
        {
            this.Pergunta = "";
            this.Resposta = "";
        }

        public Charada(string pergunta, string resposta)
        {
            this.Pergunta = pergunta;
            this.Resposta = resposta;
        }

        public string Pergunta { get; set; }
        public string Resposta { get; set; }
    }
}
