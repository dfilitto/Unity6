﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesafioDaEsfinge
{
    public class Esfinge
    {
        private List<Charada> charadas;
        private Random random;
        private Charada charadaAtual;
        public Esfinge()
        {
            charadas = new List<Charada>
        {
            new Charada("O que é, o que é? Quanto mais se tira, maior fica.", "Buraco"),
            new Charada("O que tem no meio do ovo?", "V"),
            new Charada("O que é, o que é? Tem cabeça, tem dente, não é bicho e nem é gente.", "Alho"),
            new Charada("O que é, o que é? De dia tem quatro patas, à tarde tem duas e à noite tem três.", "Homem")
        };
            random = new Random();
            SelecionarNovaCharada();
        }

        public void SelecionarNovaCharada()
        {
            charadaAtual = charadas[random.Next(charadas.Count)];
        }

        public string ObterPergunta()
        {
            return charadaAtual.Pergunta;
        }

        public string ObterResposta()
        {
            return charadaAtual.Resposta;
        }
    }
}
