﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DesafioDaEsfinge
{
    public class Program
    {
        static void Main(string[] args)
        {
            Esfinge esfinge = new Esfinge();
            Console.WriteLine("Programa responda ou te devoro");
            Console.WriteLine("Olá, eu sou a Esfinge que protege a entrada do paraíso.");
            Console.WriteLine("Responda a minha charada e estará livre para passar, você terá três tentativas.");
            Console.WriteLine("Caso não consiga, você estará condenado a passar a eternidade em sofrimento.");
            Console.WriteLine("Será professor pelo resto eternidade hahahahahha!!!!!!!!!");
            Console.ReadKey();
            string resposta = "";
            int chances = 3;
            while (chances > 0 && resposta.ToLower()!=esfinge.ObterResposta().ToLower()) {
                Console.Clear();
                Console.WriteLine($"Você tem {chances} chances de acertar a charada!!!!!");
                Console.WriteLine($"Charada:{esfinge.ObterPergunta()}");
                Console.Write("Resposta: ");
                resposta = Console.ReadLine();
                if (resposta.ToLower() != esfinge.ObterResposta().ToLower())
                {
                    Console.WriteLine("HA HA HA HA. Você errou!!!!!! ");
                    Console.ReadKey();
                }
                chances--;
            }
            Console.Clear();
            if (resposta.ToLower() == esfinge.ObterResposta().ToLower())
            {
                Console.WriteLine("Parabens!!!!!!! Você Pode ir para o paraiso");
            }
            else
            {
                Console.WriteLine("A sua hora chegou!!!!! você será um professor eternamente.");
            }
            Console.ReadKey();
        }
    }
}
