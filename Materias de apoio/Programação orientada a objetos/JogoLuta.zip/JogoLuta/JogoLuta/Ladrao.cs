﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Server;

namespace JogoLuta
{

    public class Ladrao:Personagem
    {
        static int Instanciados = 0;
        static Random random = new Random();
        public Ladrao() : base()
        {
            Ladrao.Instanciados++;
            this.Nome = $"Guerreiro ({Ladrao.Instanciados})";
            this.forca = 5;
            this.classePersonagem = "Ladrão";
        }

        public Ladrao(string nome, int vida) : base(nome, vida)
        {
            this.forca = 5;
            this.classePersonagem = "Ladrão";
        }

        public override int Atacar()
        {
            int forca = random.Next(0,this.forca);
            Console.WriteLine($"{this.Nome} jogou sua pedra com uma força de {this.forca} !!!!!");
            return forca;
        }
    }
}
