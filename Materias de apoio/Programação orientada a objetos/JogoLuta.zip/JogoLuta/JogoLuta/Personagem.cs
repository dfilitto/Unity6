﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JogoLuta
{
    public class Personagem
    {
        //tipo do personagem
        protected int forca = 0;
        protected string classePersonagem;
        //construtor - serve para dar vida ao objeto
        public Personagem() 
        {
            this.Nome = "Personagem Padrão";
            this.Vida = 100;
            this.forca = 15;
            this.classePersonagem = "Padrão";
        }

        public Personagem(string nome, int vida)
        {
            this.Nome = nome;
            this.Vida = vida;
            this.forca = 15;
            this.classePersonagem = "Padrão";
        }
        //propriedades e suas variaveis
        public string Nome { 
            get; 
            set; 
        }

        private int vida;
        public int Vida
        {
            get 
            {
                return vida; 
            }
            set 
            {
                if (value < 0)
                {
                    vida = 0;
                }
                else
                {
                    vida = value;
                }
            }
        }

        public string Classe
        {
            get { return this.classePersonagem; }
        }

        //metodos dos objetos
        public virtual int Atacar()
        {
            Console.WriteLine($"{this.Nome} atacou com uma força de {this.forca} !!!!!");
            return forca;
        }
        
    }
}
