﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JogoLuta
{
    internal class Arqueiro:Personagem
    {
        static int Instanciados = 0;
        static Random random = new Random();
        public Arqueiro():base() 
        {
            Arqueiro.Instanciados++;
            this.Nome = $"Guerreiro ({Arqueiro.Instanciados})";
            this.forca = 20;
            this.classePersonagem = "Arqueiro";
        }

        public Arqueiro(string nome, int vida) : base(nome, vida) 
        {
            this.forca = 20;
            this.classePersonagem = "Arqueiro";
        }

        public override int Atacar()
        {
            int forca = random.Next(0,this.forca);
            Console.WriteLine($"{this.Nome} desferiu sua flecha com uma  força de {this.forca} !!!!!");
            return forca;
        }
    }
}
