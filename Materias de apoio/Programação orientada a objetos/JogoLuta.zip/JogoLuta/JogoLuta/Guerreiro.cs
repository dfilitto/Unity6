﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JogoLuta
{
    public class Guerreiro:Personagem
    {
        static int Instanciados = 0;
        static Random random = new Random();
        public Guerreiro():base() 
        {
            Guerreiro.Instanciados++;
            this.Nome = $"Guerreiro ({Guerreiro.Instanciados})";
            //this.Vida = 100;
            this.forca = 30;
            this.classePersonagem = "Guerreiro";
        }

        public Guerreiro(string nome, int vida):base(nome, vida) 
        {
            this.forca = 30;
        }

        public override int Atacar()
        {
            int forca = Guerreiro.random.Next(0,this.forca);
            //fazer com que a força seja de 0 até forca
            Console.WriteLine($"{this.Nome} atacou com sua espada com uma  força de {forca} !!!!!");
            return forca;
        }        
    }
}
