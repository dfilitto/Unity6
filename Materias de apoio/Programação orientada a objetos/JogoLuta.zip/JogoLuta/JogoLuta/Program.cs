﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace JogoLuta
{

    internal class Program
    {
        /*
          Jogo de luta, ganha quem ficar vivo no final
            Classes (Guerreiro, Arquiro, Ladrão, Professor)
            Guerreiro -> "nome" atacou com sua espada com uma força de "30" 
            Arqueiro -> "nome" desferiu sua flecha com uma  força de "20" 
            Ladrão -> "nome" jogou sua pedra com uma força de "5"
         */
        static void Main(string[] args)
        {
            string op = "S";
            while (op != "N")
            { //jogar novamente o jogo
                Random random = new Random();
                int tipoPC = random.Next(3) + 1;
                Personagem pc = new Personagem();
                if (tipoPC == 1) pc = new Guerreiro();
                if (tipoPC == 2) pc = new Arqueiro();
                if (tipoPC == 3) pc = new Ladrao();
                pc.Nome = "Computador";

                int tipoUser = 0; //Saber se o usuario é arquiro, guerreiro, ladrão
                Personagem user;

                Console.Clear();
                Console.WriteLine("Jogo de luta contra o PC");
                //Usuario escolhe quem ele vai ser jogo jogo
                Console.WriteLine("Qual classe de Personagem você quer ser 1 - Guerreiro | 2 - Arqueiro | 3 - Ladrão");
                Console.Write("Classe: ");
                tipoUser = Convert.ToInt32(Console.ReadLine());
                user = new Guerreiro();
                if (tipoUser == 1) user = new Guerreiro();
                if (tipoUser == 2) user = new Arqueiro();
                if (tipoUser == 3) user = new Ladrao();

                Console.Write("Nome do Jogador: ");
                user.Nome = Console.ReadLine();

                //Mostrar os dados dos lutadores
                Console.WriteLine("Lutadores");
                Console.WriteLine($"Player 1 - Nome: {pc.Nome} - Vida: {pc.Vida} - Classe: {pc.Classe}");
                Console.WriteLine($"Player 2 - Nome: {user.Nome} - Vida: {user.Vida} - Classe: {pc.Classe}");
                Thread.Sleep(1500);
                while (user.Vida > 0 && pc.Vida > 0)
                {
                    Console.Clear();

                    pc.Vida = pc.Vida - user.Atacar();
                    user.Vida = user.Vida - pc.Atacar();
                    Console.WriteLine($"Player 1 - Nome: {pc.Nome} - Vida: {pc.Vida} - Classe: {pc.Classe}");
                    Console.WriteLine($"Player 2 - Nome: {user.Nome} - Vida: {user.Vida} - Classe: {pc.Classe}");
                    Thread.Sleep(3000);
                }

                if (user.Vida > 0)
                    Console.WriteLine("Vencedor: " + user.Nome);
                else
                    Console.WriteLine("Vencedor: " + pc.Nome);

                Console.Write("Deseja jogar novamente S/N:");
                op = Console.ReadLine();

            }


        }
    }
}
